#include <iostream>
 using namespace std;
 int main(){
 
 // Inicio del bloque de código
cout << "Esto es una cadena constante que se escribe tal cual." ;
cout << endl;
cout << lunes ;
cout << " " ;
cout << 2 ;
cout << " " ;
cout << 4.000000 ;
cout << endl;
cout << domingo ;
cout << " " ;
cout << 13 ;
cout << " " ;
cout << 21.000000 ;
cout << endl;
cout << endl;
cout << lunes ;
cout << endl;
cout << martes ;
cout << endl;
cout << miercoles ;
cout << endl;
cout << jueves ;
cout << endl;
cout << viernes ;
cout << endl;
cout << "Dias laborables" ;
cout << endl;
cout << endl;
cout << endl;
cout << "Adios" ;
cout << endl;
// Final del bloque de código
 
return 0;
 }
 
